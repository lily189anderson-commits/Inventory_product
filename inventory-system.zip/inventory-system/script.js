/* =========================================================
   Smart Inventory & Sales - script.js
   Plain JavaScript only. Sections:
     1. Settings & data
     2. Saving / loading (localStorage)
     3. Small helper functions
     4. Page switching
     5. Dashboard
     6. Products (add, edit, delete, search, filter, sort)
     7. New sale (cart + checkout)
     8. Sales history
     9. Start the app
   ========================================================= */

/* ---------------------------------------------------------
   1. SETTINGS & DATA
   --------------------------------------------------------- */
var PRODUCTS_KEY = "sis_products";
var SALES_KEY = "sis_sales";

var DISCOUNT_LIMIT = 10000;   // discount starts at this subtotal
var DISCOUNT_RATE = 0.10;     // 10%
var TAX_RATE = 0.05;          // 5%

var products = [];   // all products
var sales = [];      // all completed sales
var cart = [];       // current cart: [{ id: "PRD-001", qty: 2 }]
var editingId = null; // null = adding a new product, otherwise the ID being edited

/* ---------------------------------------------------------
   2. SAVING / LOADING
   --------------------------------------------------------- */

// Read a list from localStorage. If anything is wrong, return an empty list.
function loadList(key) {
  try {
    var text = localStorage.getItem(key);
    if (!text) return [];
    var data = JSON.parse(text);
    if (!Array.isArray(data)) return [];
    return data;
  } catch (e) {
    return [];
  }
}

// Remove broken products (missing fields, bad numbers) so the app never crashes.
function cleanProducts(list) {
  var good = [];
  var seen = {};
  list.forEach(function (p) {
    if (!p || typeof p !== "object") return;
    var id = String(p.id || "").trim();
    var name = String(p.name || "").trim();
    var purchase = Number(p.purchasePrice);
    var selling = Number(p.sellingPrice);
    var qty = Number(p.quantity);
    var min = Number(p.minStock);
    if (!id || !name || seen[id.toLowerCase()]) return;
    if (!(purchase > 0) || !(selling > 0)) return;
    if (!Number.isInteger(qty) || qty < 0) return;
    if (!Number.isInteger(min) || min < 0) min = 0;
    seen[id.toLowerCase()] = true;
    good.push({
      id: id,
      name: name,
      category: String(p.category || "General").trim() || "General",
      purchasePrice: purchase,
      sellingPrice: selling,
      quantity: qty,
      minStock: min
    });
  });
  return good;
}

// Remove broken sales.
function cleanSales(list) {
  var good = [];
  list.forEach(function (s) {
    if (!s || typeof s !== "object") return;
    if (!s.id || !s.time || !Array.isArray(s.items)) return;
    if (isNaN(new Date(s.time).getTime())) return;
    if (typeof s.total !== "number" || isNaN(s.total)) return;
    var items = s.items.filter(function (i) {
      return i && i.name && Number(i.qty) > 0 && Number(i.price) >= 0;
    });
    if (items.length === 0) return;
    good.push({
      id: String(s.id),
      time: s.time,
      items: items,
      subtotal: Number(s.subtotal) || 0,
      discount: Number(s.discount) || 0,
      tax: Number(s.tax) || 0,
      total: s.total
    });
  });
  return good;
}

// Save both lists. Returns true if it worked, false if the browser refused.
function saveAll() {
  try {
    localStorage.setItem(PRODUCTS_KEY, JSON.stringify(products));
    localStorage.setItem(SALES_KEY, JSON.stringify(sales));
    return true;
  } catch (e) {
    return false;
  }
}

/* ---------------------------------------------------------
   3. SMALL HELPER FUNCTIONS
   --------------------------------------------------------- */

// Shortcut: document.getElementById
function $(id) {
  return document.getElementById(id);
}

// Make text safe before putting it inside HTML
function esc(text) {
  return String(text)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

// 12500 -> "PKR 12,500"
function money(amount) {
  var rounded = Math.round(amount * 100) / 100;
  return "PKR " + rounded.toLocaleString("en-US", { maximumFractionDigits: 2 });
}

// Round to 2 decimals (avoids 0.1 + 0.2 problems)
function round2(n) {
  return Math.round(n * 100) / 100;
}

// Find a product by ID
function findProduct(id) {
  for (var i = 0; i < products.length; i++) {
    if (products[i].id === id) return products[i];
  }
  return null;
}

// "ok", "low" or "out" for a product
function stockStatus(p) {
  if (p.quantity === 0) return "out";
  if (p.quantity <= p.minStock) return "low";
  return "ok";
}

function statusBadge(p) {
  var s = stockStatus(p);
  if (s === "out") return '<span class="badge out">Out of stock</span>';
  if (s === "low") return '<span class="badge low">Low stock</span>';
  return '<span class="badge ok">In stock</span>';
}

// Small message at the bottom of the screen
var toastTimer = null;
function toast(message, isError) {
  var box = $("toast");
  box.textContent = message;
  box.className = "toast" + (isError ? " error" : "");
  box.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(function () {
    box.hidden = true;
  }, 2800);
}

// "Nothing here yet" message
function emptyMessage(title, text, buttonHtml) {
  return '<div class="empty"><strong>' + title + "</strong>" + text + (buttonHtml || "") + "</div>";
}

// Date as YYYY-MM-DD in the user's local time (used for the date filter)
function dateOnly(isoText) {
  var d = new Date(isoText);
  var m = String(d.getMonth() + 1).padStart(2, "0");
  var day = String(d.getDate()).padStart(2, "0");
  return d.getFullYear() + "-" + m + "-" + day;
}

function niceDateTime(isoText) {
  return new Date(isoText).toLocaleString("en-GB", {
    day: "2-digit", month: "short", year: "numeric",
    hour: "2-digit", minute: "2-digit"
  });
}

/* ---------------------------------------------------------
   4. PAGE SWITCHING
   --------------------------------------------------------- */
function showPage(name) {
  document.querySelectorAll(".page").forEach(function (page) {
    page.classList.remove("active");
  });
  document.querySelectorAll(".menu-btn").forEach(function (btn) {
    btn.classList.toggle("active", btn.dataset.page === name);
  });
  $("page-" + name).classList.add("active");

  // refresh the page we are opening
  if (name === "dashboard") renderDashboard();
  if (name === "products") renderProducts();
  if (name === "sale") renderSalePage();
  if (name === "history") renderHistory();
}

/* ---------------------------------------------------------
   5. DASHBOARD
   --------------------------------------------------------- */
function renderDashboard() {
  // numbers
  var revenue = 0;
  sales.forEach(function (s) { revenue += s.total; });

  var lowList = products.filter(function (p) {
    return p.quantity <= p.minStock;
  });

  var costValue = 0;
  products.forEach(function (p) { costValue += p.purchasePrice * p.quantity; });

  $("stat-products").textContent = products.length;
  $("stat-revenue").textContent = money(revenue);
  $("stat-orders").textContent = sales.length;
  $("stat-low").textContent = lowList.length;
  $("stat-cost").textContent = money(costValue);

  // top selling product (by total units sold)
  var unitsByName = {};
  sales.forEach(function (s) {
    s.items.forEach(function (item) {
      var key = item.name;
      unitsByName[key] = (unitsByName[key] || 0) + Number(item.qty);
    });
  });
  var topName = null;
  var topUnits = 0;
  Object.keys(unitsByName).forEach(function (name) {
    if (unitsByName[name] > topUnits) {
      topUnits = unitsByName[name];
      topName = name;
    }
  });

  if (topName) {
    $("top-product").innerHTML =
      '<p class="top-name">' + esc(topName) + "</p>" +
      '<p class="muted">' + topUnits + " units sold</p>";
  } else {
    $("top-product").innerHTML = '<p class="muted">No sales yet. Complete a sale to see your best seller here.</p>';
  }

  // low stock list
  if (lowList.length === 0) {
    $("low-stock-list").innerHTML = '<p class="muted">All products have enough stock.</p>';
  } else {
    var html = "";
    lowList.forEach(function (p) {
      html +=
        '<div class="list-row"><span><strong>' + esc(p.name) + "</strong> (" + esc(p.id) + ")</span>" +
        "<span>" + p.quantity + " left (min " + p.minStock + ") " + statusBadge(p) + "</span></div>";
    });
    $("low-stock-list").innerHTML = html;
  }
}

/* ---------------------------------------------------------
   6. PRODUCTS
   --------------------------------------------------------- */

// Fill the category drop-down and the category suggestions in the form
function refreshCategories() {
  var cats = [];
  products.forEach(function (p) {
    if (cats.indexOf(p.category) === -1) cats.push(p.category);
  });
  cats.sort();

  var select = $("product-category");
  var current = select.value;
  var html = '<option value="">All categories</option>';
  cats.forEach(function (c) {
    html += '<option value="' + esc(c) + '">' + esc(c) + "</option>";
  });
  select.innerHTML = html;
  select.value = cats.indexOf(current) === -1 ? "" : current;

  var list = "";
  cats.forEach(function (c) { list += '<option value="' + esc(c) + '">'; });
  $("category-list").innerHTML = list;
}

// Apply search + category filter + sorting
function getVisibleProducts() {
  var search = $("product-search").value.trim().toLowerCase();
  var category = $("product-category").value;
  var sortBy = $("product-sort").value;

  var list = products.filter(function (p) {
    var matchSearch = p.name.toLowerCase().indexOf(search) !== -1 ||
                      p.id.toLowerCase().indexOf(search) !== -1;
    var matchCategory = category === "" || p.category === category;
    return matchSearch && matchCategory;
  });

  list.sort(function (a, b) {
    if (sortBy === "price") return a.sellingPrice - b.sellingPrice;
    if (sortBy === "quantity") return a.quantity - b.quantity;
    return a.name.localeCompare(b.name);
  });
  return list;
}

function renderProducts() {
  refreshCategories();
  var list = getVisibleProducts();
  var html = "";

  list.forEach(function (p) {
    var rowClass = stockStatus(p) === "out" ? ' class="row-out"' : "";
    html +=
      "<tr" + rowClass + ">" +
      "<td>" + esc(p.id) + "</td>" +
      "<td><strong>" + esc(p.name) + "</strong></td>" +
      "<td>" + esc(p.category) + "</td>" +
      '<td class="num">' + money(p.purchasePrice) + "</td>" +
      '<td class="num">' + money(p.sellingPrice) + "</td>" +
      '<td class="num">' + p.quantity + "</td>" +
      '<td class="num">' + p.minStock + "</td>" +
      "<td>" + statusBadge(p) + "</td>" +
      '<td class="actions">' +
        '<button class="btn ghost small" data-edit="' + esc(p.id) + '">Edit</button>' +
        '<button class="btn danger small" data-delete="' + esc(p.id) + '">Delete</button>' +
      "</td></tr>";
  });
  $("product-table").innerHTML = html;

  // empty messages
  if (products.length === 0) {
    $("product-empty").innerHTML = emptyMessage(
      "No products yet",
      "Add your first product to start tracking stock.",
      '<br><button class="btn primary" id="btn-sample">Add 5 sample products</button>'
    );
  } else if (list.length === 0) {
    $("product-empty").innerHTML = emptyMessage("No match", "Try a different search or category.");
  } else {
    $("product-empty").innerHTML = "";
  }
}

// ----- Add / edit window -----
function openProductForm(id) {
  editingId = id;
  $("form-error").textContent = "";

  if (id) {
    var p = findProduct(id);
    $("modal-title").textContent = "Edit product";
    $("f-id").value = p.id;
    $("f-id").disabled = true; // ID cannot change when editing
    $("f-name").value = p.name;
    $("f-category").value = p.category;
    $("f-purchase").value = p.purchasePrice;
    $("f-selling").value = p.sellingPrice;
    $("f-quantity").value = p.quantity;
    $("f-min").value = p.minStock;
  } else {
    $("modal-title").textContent = "Add product";
    $("f-id").disabled = false;
    ["f-id", "f-name", "f-category", "f-purchase", "f-selling", "f-quantity", "f-min"].forEach(function (f) {
      $(f).value = "";
    });
  }

  $("product-modal").hidden = false;
  $(id ? "f-name" : "f-id").focus();
}

function closeProductForm() {
  $("product-modal").hidden = true;
}

// Check the form. Returns an error message, or "" if everything is fine.
function validateProductForm() {
  var id = $("f-id").value.trim();
  var name = $("f-name").value.trim();
  var category = $("f-category").value.trim();
  var purchaseText = $("f-purchase").value.trim();
  var sellingText = $("f-selling").value.trim();
  var qtyText = $("f-quantity").value.trim();
  var minText = $("f-min").value.trim();

  if (!id) return "Product ID is required.";
  if (!name) return "Product name is required.";
  if (!category) return "Category is required.";
  if (purchaseText === "") return "Purchase price is required.";
  if (sellingText === "") return "Selling price is required.";
  if (qtyText === "") return "Quantity is required.";
  if (minText === "") return "Minimum stock is required.";

  var purchase = Number(purchaseText);
  var selling = Number(sellingText);
  var qty = Number(qtyText);
  var min = Number(minText);

  if (isNaN(purchase) || purchase <= 0) return "Purchase price must be more than 0.";
  if (isNaN(selling) || selling <= 0) return "Selling price must be more than 0.";
  if (!Number.isInteger(qty) || qty < 0) return "Quantity must be a whole number (0 or more).";
  if (!Number.isInteger(min) || min < 0) return "Minimum stock must be a whole number (0 or more).";

  // duplicate ID check (only when adding)
  if (editingId === null) {
    for (var i = 0; i < products.length; i++) {
      if (products[i].id.toLowerCase() === id.toLowerCase()) {
        return 'A product with ID "' + id + '" already exists.';
      }
    }
  }
  return "";
}

function saveProductForm() {
  var error = validateProductForm();
  if (error) {
    $("form-error").textContent = error;
    return;
  }

  var data = {
    id: $("f-id").value.trim(),
    name: $("f-name").value.trim(),
    category: $("f-category").value.trim(),
    purchasePrice: Number($("f-purchase").value),
    sellingPrice: Number($("f-selling").value),
    quantity: Number($("f-quantity").value),
    minStock: Number($("f-min").value)
  };

  var backup = JSON.stringify(products);

  if (editingId === null) {
    products.push(data);
  } else {
    var index = products.indexOf(findProduct(editingId));
    products[index] = data;
  }

  if (!saveAll()) {
    products = JSON.parse(backup); // undo
    $("form-error").textContent = "Could not save. Your browser storage may be full or blocked.";
    return;
  }

  // keep the cart valid if stock was edited
  fixCartAfterStockChange();

  var wasEditing = editingId !== null;
  closeProductForm();
  renderProducts();
  toast(wasEditing ? "Product updated" : "Product added");
}

function deleteProduct(id) {
  var p = findProduct(id);
  if (!p) return;
  if (!confirm('Delete "' + p.name + '"? This cannot be undone.')) return;

  var backup = JSON.stringify(products);
  products = products.filter(function (x) { return x.id !== id; });

  if (!saveAll()) {
    products = JSON.parse(backup);
    toast("Could not delete. Storage problem.", true);
    return;
  }
  cart = cart.filter(function (c) { return c.id !== id; });
  renderProducts();
  toast("Product deleted");
}

function addSampleProducts() {
  var samples = [
    { id: "PRD-001", name: "Wireless Mouse", category: "Electronics", purchasePrice: 1200, sellingPrice: 1800, quantity: 25, minStock: 5 },
    { id: "PRD-002", name: "USB Keyboard", category: "Electronics", purchasePrice: 1500, sellingPrice: 2300, quantity: 12, minStock: 5 },
    { id: "PRD-003", name: "A4 Paper Pack", category: "Stationery", purchasePrice: 900, sellingPrice: 1200, quantity: 4, minStock: 10 },
    { id: "PRD-004", name: "Gel Pen Box", category: "Stationery", purchasePrice: 250, sellingPrice: 400, quantity: 40, minStock: 10 },
    { id: "PRD-005", name: "Phone Charger", category: "Electronics", purchasePrice: 700, sellingPrice: 1100, quantity: 0, minStock: 5 }
  ];
  samples.forEach(function (s) {
    if (!findProduct(s.id)) products.push(s);
  });
  saveAll();
  renderProducts();
  toast("Sample products added");
}

/* ---------------------------------------------------------
   7. NEW SALE (cart + checkout)
   --------------------------------------------------------- */

// How many of this product are already in the cart?
function cartQty(id) {
  for (var i = 0; i < cart.length; i++) {
    if (cart[i].id === id) return cart[i].qty;
  }
  return 0;
}

// Calculate subtotal, discount, tax and total for the current cart
function calculateTotals() {
  var subtotal = 0;
  cart.forEach(function (line) {
    var p = findProduct(line.id);
    if (p) subtotal += p.sellingPrice * line.qty;
  });
  subtotal = round2(subtotal);

  var discount = subtotal >= DISCOUNT_LIMIT ? round2(subtotal * DISCOUNT_RATE) : 0;
  var afterDiscount = round2(subtotal - discount);
  var tax = round2(afterDiscount * TAX_RATE);
  var total = round2(afterDiscount + tax);

  return { subtotal: subtotal, discount: discount, tax: tax, total: total };
}

// Remove / lower cart lines if stock changed or product was removed
function fixCartAfterStockChange() {
  var fixed = [];
  cart.forEach(function (line) {
    var p = findProduct(line.id);
    if (!p || p.quantity === 0) return;
    if (line.qty > p.quantity) line.qty = p.quantity;
    fixed.push(line);
  });
  cart = fixed;
}

function renderSalePage() {
  renderSaleProducts();
  renderCart();
}

function renderSaleProducts() {
  var search = $("sale-search").value.trim().toLowerCase();
  var list = products.filter(function (p) {
    return p.name.toLowerCase().indexOf(search) !== -1 ||
           p.id.toLowerCase().indexOf(search) !== -1;
  });
  list.sort(function (a, b) { return a.name.localeCompare(b.name); });

  if (products.length === 0) {
    $("sale-products").innerHTML = emptyMessage("No products to sell", "Go to Products and add some first.");
    return;
  }
  if (list.length === 0) {
    $("sale-products").innerHTML = emptyMessage("No match", "Try a different search.");
    return;
  }

  var html = "";
  list.forEach(function (p) {
    var inCart = cartQty(p.id);
    var disabled = p.quantity === 0 || inCart >= p.quantity;
    var label = p.quantity === 0 ? "Out of stock" : (inCart >= p.quantity ? "Max in cart" : "Add");
    html +=
      '<div class="pick-row">' +
        '<div class="pick-info">' +
          '<div class="pick-name">' + esc(p.name) + "</div>" +
          '<div class="pick-meta">' + esc(p.id) + " · " + money(p.sellingPrice) + " · " + p.quantity + " in stock " + statusBadge(p) + "</div>" +
        "</div>" +
        '<button class="btn primary small" data-add="' + esc(p.id) + '"' + (disabled ? " disabled" : "") + ">" + label + "</button>" +
      "</div>";
  });
  $("sale-products").innerHTML = html;
}

function renderCart() {
  var html = "";

  if (cart.length === 0) {
    html = emptyMessage("Cart is empty", "Add products from the list.");
  } else {
    cart.forEach(function (line) {
      var p = findProduct(line.id);
      if (!p) return;
      html +=
        '<div class="cart-row">' +
          '<div class="cart-top"><span>' + esc(p.name) + "</span><span>" + money(p.sellingPrice * line.qty) + "</span></div>" +
          '<div class="cart-controls">' +
            '<button class="btn ghost small" data-minus="' + esc(p.id) + '">−</button>' +
            '<span class="qty">' + line.qty + "</span>" +
            '<button class="btn ghost small" data-plus="' + esc(p.id) + '"' + (line.qty >= p.quantity ? " disabled" : "") + ">+</button>" +
            '<button class="btn danger small" data-remove="' + esc(p.id) + '">Remove</button>' +
            '<span class="unit">' + money(p.sellingPrice) + " each</span>" +
          "</div>" +
        "</div>";
    });
  }
  $("cart-items").innerHTML = html;

  var t = calculateTotals();
  $("cart-subtotal").textContent = money(t.subtotal);
  $("cart-discount").textContent = "− " + money(t.discount);
  $("cart-tax").textContent = money(t.tax);
  $("cart-total").textContent = money(t.total);

  $("btn-checkout").disabled = cart.length === 0;
  $("btn-clear-cart").disabled = cart.length === 0;
}

function addToCart(id) {
  var p = findProduct(id);
  if (!p) return;
  var line = null;
  cart.forEach(function (c) { if (c.id === id) line = c; });

  if (line) {
    if (line.qty >= p.quantity) {
      toast("Only " + p.quantity + " in stock", true);
      return;
    }
    line.qty += 1;
  } else {
    if (p.quantity < 1) {
      toast("This product is out of stock", true);
      return;
    }
    cart.push({ id: id, qty: 1 });
  }
  renderSalePage();
}

function changeCartQty(id, change) {
  var p = findProduct(id);
  cart.forEach(function (line) {
    if (line.id !== id) return;
    var newQty = line.qty + change;
    if (change > 0 && p && newQty > p.quantity) {
      toast("Only " + p.quantity + " in stock", true);
      return;
    }
    line.qty = newQty;
  });
  cart = cart.filter(function (line) { return line.qty > 0; });
  renderSalePage();
}

function removeFromCart(id) {
  cart = cart.filter(function (line) { return line.id !== id; });
  renderSalePage();
}

// Make the next sale ID: SALE-0001, SALE-0002 ...
function nextSaleId() {
  var highest = 0;
  sales.forEach(function (s) {
    var match = /^SALE-(\d+)$/.exec(s.id);
    if (match) highest = Math.max(highest, Number(match[1]));
  });
  return "SALE-" + String(highest + 1).padStart(4, "0");
}

function checkout() {
  // 1) no empty orders
  if (cart.length === 0) {
    toast("Cart is empty. Add a product first.", true);
    return;
  }

  // 2) check stock for EVERY item before changing anything
  for (var i = 0; i < cart.length; i++) {
    var p = findProduct(cart[i].id);
    if (!p) {
      toast("A product in the cart no longer exists.", true);
      return;
    }
    if (cart[i].qty < 1 || cart[i].qty > p.quantity) {
      toast("Not enough stock for " + p.name + ".", true);
      return;
    }
  }

  if (!confirm("Complete this sale?")) return;

  // 3) keep a backup so we can undo if saving fails
  var productsBackup = JSON.stringify(products);
  var salesBackup = JSON.stringify(sales);

  var totals = calculateTotals();
  var items = [];
  cart.forEach(function (line) {
    var product = findProduct(line.id);
    items.push({
      id: product.id,
      name: product.name,
      price: product.sellingPrice,
      qty: line.qty,
      lineTotal: round2(product.sellingPrice * line.qty)
    });
    product.quantity -= line.qty; // deduct stock
  });

  var sale = {
    id: nextSaleId(),
    time: new Date().toISOString(),
    items: items,
    subtotal: totals.subtotal,
    discount: totals.discount,
    tax: totals.tax,
    total: totals.total
  };
  sales.push(sale);

  // 4) save. If it fails, put everything back exactly as it was.
  if (!saveAll()) {
    products = JSON.parse(productsBackup);
    sales = JSON.parse(salesBackup);
    toast("Checkout failed. Nothing was changed.", true);
    renderSalePage();
    return;
  }

  cart = [];
  renderSalePage();
  toast("Sale " + sale.id + " completed: " + money(sale.total));
}

function clearCart() {
  if (cart.length === 0) return;
  if (!confirm("Remove everything from the cart?")) return;
  cart = [];
  renderSalePage();
}

/* ---------------------------------------------------------
   8. SALES HISTORY
   --------------------------------------------------------- */
function renderHistory() {
  var search = $("history-search").value.trim().toLowerCase();
  var date = $("history-date").value; // "" or YYYY-MM-DD

  var list = sales.filter(function (s) {
    var matchId = s.id.toLowerCase().indexOf(search) !== -1;
    var matchDate = date === "" || dateOnly(s.time) === date;
    return matchId && matchDate;
  });

  // newest first
  list.sort(function (a, b) { return new Date(b.time) - new Date(a.time); });

  var html = "";
  list.forEach(function (s) {
    var itemsHtml = "";
    s.items.forEach(function (item) {
      itemsHtml += "<div>" + esc(item.name) + " × " + item.qty + "</div>";
    });
    html +=
      "<tr>" +
      "<td><strong>" + esc(s.id) + "</strong></td>" +
      "<td>" + niceDateTime(s.time) + "</td>" +
      '<td class="items-cell">' + itemsHtml + "</td>" +
      '<td class="num"><strong>' + money(s.total) + "</strong></td>" +
      "</tr>";
  });
  $("history-table").innerHTML = html;

  if (sales.length === 0) {
    $("history-empty").innerHTML = emptyMessage("No sales yet", "Completed sales will appear here.");
  } else if (list.length === 0) {
    $("history-empty").innerHTML = emptyMessage("No sales found", "Try another sale ID or date.");
  } else {
    $("history-empty").innerHTML = "";
  }
}

/* ---------------------------------------------------------
   9. START THE APP
   --------------------------------------------------------- */
function setupButtons() {
  // menu
  document.querySelectorAll(".menu-btn").forEach(function (btn) {
    btn.addEventListener("click", function () { showPage(btn.dataset.page); });
  });

  // products page
  $("btn-add-product").addEventListener("click", function () { openProductForm(null); });
  $("product-search").addEventListener("input", renderProducts);
  $("product-category").addEventListener("change", renderProducts);
  $("product-sort").addEventListener("change", renderProducts);

  // clicks inside the product area (edit, delete, sample button)
  $("page-products").addEventListener("click", function (e) {
    var t = e.target;
    if (t.dataset.edit) openProductForm(t.dataset.edit);
    if (t.dataset.delete) deleteProduct(t.dataset.delete);
    if (t.id === "btn-sample") addSampleProducts();
  });

  // add / edit window
  $("btn-save").addEventListener("click", saveProductForm);
  $("btn-cancel").addEventListener("click", closeProductForm);
  $("product-modal").addEventListener("click", function (e) {
    if (e.target === $("product-modal")) closeProductForm(); // click outside
  });
  $("product-modal").addEventListener("keydown", function (e) {
    if (e.key === "Escape") closeProductForm();
    if (e.key === "Enter" && e.target.tagName === "INPUT") saveProductForm();
  });

  // sale page
  $("sale-search").addEventListener("input", renderSaleProducts);
  $("page-sale").addEventListener("click", function (e) {
    var t = e.target;
    if (t.dataset.add) addToCart(t.dataset.add);
    if (t.dataset.plus) changeCartQty(t.dataset.plus, 1);
    if (t.dataset.minus) changeCartQty(t.dataset.minus, -1);
    if (t.dataset.remove) removeFromCart(t.dataset.remove);
  });
  $("btn-checkout").addEventListener("click", checkout);
  $("btn-clear-cart").addEventListener("click", clearCart);

  // history page
  $("history-search").addEventListener("input", renderHistory);
  $("history-date").addEventListener("change", renderHistory);
  $("btn-clear-filters").addEventListener("click", function () {
    $("history-search").value = "";
    $("history-date").value = "";
    renderHistory();
  });
}

// Load saved data, then show the dashboard
products = cleanProducts(loadList(PRODUCTS_KEY));
sales = cleanSales(loadList(SALES_KEY));
setupButtons();
showPage("dashboard");
