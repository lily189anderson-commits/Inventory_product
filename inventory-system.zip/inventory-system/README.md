# Smart Inventory & Sales Management System

A browser-based inventory and sales app for a small shop. Built with plain HTML, CSS and vanilla JavaScript. No framework, no backend, no installation.

## How to run

1. Keep these files together in one folder: `index.html`, `style.css`, `script.js`.
2. Double-click `index.html` (or right-click, then Open with, then your browser).
3. That is all. Works in Chrome, Edge, Firefox and Safari, on desktop and mobile.

## What it does

- **Dashboard:** total products, total revenue, completed orders, low-stock count, top-selling product, inventory cost value, and a list of products that need restocking.
- **Products:** add, edit and delete (with confirmation). Search by name or ID, filter by category, sort by name, selling price or quantity.
- **New Sale:** add products to a cart, change quantities, remove items. Quantities can never go above available stock. 10% discount when the subtotal is PKR 10,000 or more, then 5% tax on the discounted amount. Discount, tax and grand total are shown separately.
- **Sales History:** every completed sale with ID, date and time, items, quantities and final amount. Search by sale ID and filter by date.
- **Saving:** products and sales are stored in the browser's `localStorage`, so they are still there after a refresh or reopening the page in the same browser.

## Suggested test flow

1. Open the Dashboard (all zeros at first).
2. Go to Products and click **Add 5 sample products** (or add your own).
3. Go to New Sale, add several products, check the totals, click **Complete checkout**.
4. Go back to Products: stock has gone down.
5. Open Sales History and find the order.
6. Refresh the browser: everything is still there.

## Calculation example

Subtotal PKR 12,000 gives discount PKR 1,200, so the amount after discount is PKR 10,800. Tax is 5% of 10,800 = PKR 540. Grand total is PKR 11,340.

## Files

| File | Purpose |
|------|---------|
| `index.html` | Page structure (4 sections + add/edit window) |
| `style.css` | All styling, including the mobile layout |
| `script.js` | All logic, split into numbered sections with comments |

## Assumptions

- Product IDs are not case-sensitive for duplicate checks (`prd-001` and `PRD-001` count as the same ID).
- A product's ID cannot be changed while editing (this keeps IDs unique).
- "Low stock" means quantity is at or below the minimum threshold. Out-of-stock products (quantity 0) are also counted in the low-stock number on the Dashboard, and are shown with their own "Out of stock" badge.
- Each sale stores a copy of the product name and price at the time of sale, so history stays correct even if a product is later edited or deleted.
- The top-selling product is calculated from total units sold in saved sales.
- Sale IDs look like `SALE-0001`, counting up from the highest existing one.
- Amounts are shown in PKR and rounded to 2 decimal places.

## Limitations

- Data lives only in the browser where it was entered. A different browser, device or private window will not see it. Clearing browser data removes it.
- No login, no multiple users, no refunds or returns.
- No export or backup feature.
- Invalid or damaged saved data is ignored instead of crashing the app, which means broken records are dropped.
